//////import UIKit
////
//////var greeting = "Hello, playground"
////
////class Calculator {
////    
////    
////        // Todo : 내부 구현하기
////}
////
////let calculator = Calculator() // 인스턴스 생성하여 변수에 할당
////
////// Todo : calculator 변수를 활용하여 사칙연산을 진행
////
////class Calculator {
////  var firstNumber: Double
////  var secondNumber: Double
////  init(_ first: Double, _ second: Double) {
////    self.firstNumber = first
////    self.secondNumber = second
////  }
////  func add() -> Double{
////    return firstNumber + secondNumber
////  }
////  func minus() -> Double{
////    return firstNumber - secondNumber
////  }
////  func multiple() -> Double{
////    return firstNumber * secondNumber
////  }
////  func divide() -> Double{
////    return firstNumber / secondNumber
////  }
////}
////let calculator = Calculator(10,30)
////let add = calculator.add()
////let minus = calculator.minus()
////let multiple = calculator.multiple()
////let divide = calculator.divide()
//
//
//
//// Class 함수를 안쓰고 계산기 로직 만들어보기
//// operator 와 if 를 넣어서 해보기
//import Foundation
//class Calculator {
//let firstNumber : (Double)
//let secondNumber : (Double)
//init(_ first: Double, _ second: Double) {
//    self.firstNumber = first
//    self.secondNumber = second
//}
//func add() -> Double? {
//    return firstNumber + secondNumber
//}
//func minus() -> Double? {
//    return firstNumber - secondNumber
//}
//func multiple() -> Double? {
//    return firstNumber * secondNumber
//}
//func divide() -> Double? {
//    if secondNumber == 0 {
//        return nil
//    }else {
//        return firstNumber / secondNumber
//    }
//}
////}
////
////
//
////var calculator = Calculator(5, 10)
////let add = calculator.add()
////let minus = calculator.minus()
////let multiple = calculator.multiple()
////let divide = calculator.divide()

////함수 구현부
//func add(firstNumber:String, secondNumber: String) -> Double{
//    guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
//        return 0
//    }
//    return firstNumber + secondNumber
//}
//func sub(firstNumber:String, secondNumber: String) -> Double{
//    guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
//        return 0
//    }
//    return firstNumber - secondNumber
//}
//func mul(firstNumber:String, secondNumber: String) -> Double{
//    guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
//        return 0
//    }
//    return firstNumber * secondNumber
//}
//func div(firstNumber:String, secondNumber: String) -> Double{
//    guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
//        return 0
//    }
//    return firstNumber / secondNumber
//}
//
//func typing(typingValue: String) -> String{
//    if(typingValue == "+" || typingValue == "-" || typingValue == "*" || typingValue == "/"){
//        temp1 = viewValue
//        operatorChar = typingValue
//        viewValue = ""
//        return temp1
//    } else if(temp1 == "" && typingValue == "="){
//        temp1 = viewValue
//        viewValue = ""
//        return temp1
//    } else if(temp1 != "" && typingValue == "="){
//        temp2 = viewValue
//        if(operatorChar=="+"){
//            result = add(firstNumber: temp1, secondNumber: temp2)
//        } else if(operatorChar=="-"){
//            result = sub(firstNumber: temp1, secondNumber: temp2)
//        } else if(operatorChar=="*"){
//            result = mul(firstNumber: temp1, secondNumber: temp2)
//        } else if(operatorChar=="/"){
//            result = div(firstNumber: temp1, secondNumber: temp2)
//        }
//        temp1 = ""
//        temp2 = ""
//        viewValue = ""
//        return temp1
//    } else if let number = Int(typingValue), (0...9).contains(number){
//        return viewValue + typingValue
//    } else {
//        return ""
//    }
//    
//}
//var viewValue: String = "" // 화면에 찍힌 숫자
//var temp1: String = "" // 연산자 앞에 놓일 숫자
//var temp2: String = "" // 연산자 뒤에 놓일 숫자
//var operatorChar: String = "" // 연산자
//var result: Double = 0 // 연산의 결과
//
////초기화면
//print("값을 입력하세요.")
//
////입력부분
//viewValue = typing(typingValue: "2")
//viewValue = typing(typingValue: "4")
//viewValue = typing(typingValue: "1")
//viewValue = typing(typingValue: "+")
//viewValue = typing(typingValue: "1")
//viewValue = typing(typingValue: "=")
//
////결과부분
//print("결과: \(result)")



//class Calculator {
//    var firstNumber: String
//    var secondNumber: String
//    
//    init(firstNumber: String, secondNumber: String) {
//        self.firstNumber = firstNumber
//        self.secondNumber = secondNumber
//    }

//    func add() -> Double {
//        if let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) {
//            return firstNumber + secondNumber
//            // nil 인지 아닌지 if let 구문으로 검사를 시행.
//            // 조건문이 없어도 사용가능
//            //return A + B 는 결과값
//            
//        } else {
//            return 0
//            }
//        }
//    }

// guard let 구문은 return 값이 0이 아닐경우에는 else return 값을 추출한다. 이다.

class Calculator {
    var firstNumber: String
    var secondNumber: String
    
    init(_ firstNumber: String, _ secondNumber: String) {
        self.firstNumber = firstNumber
        self.secondNumber = secondNumber
    }
    
    // 옵셔널 바인딩 if let / guard let ==> 얘내 둘은 unwrapping  을 해야 한다
    
    
    func add() -> Double {
        guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
            return 0
        }
        return firstNumber + secondNumber }
    
    
    func sub() -> Double {
        guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
            return 0
        }
        return firstNumber - secondNumber
    }
    
    func mul() -> Double {
        guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
            return 0
        }
        return firstNumber * secondNumber
    }
    
    func div() -> Double {
        guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
            return 0
            
        }; if Double(secondNumber) == 0 {
            return 0
        } else {
            return firstNumber / secondNumber }
    }
    
    func remain() -> Double {
        guard let firstNumber = Double(firstNumber), let secondNumber = Double(secondNumber) else {
            return 0
        }
        if secondNumber == 0 {
            return 0
        } else {
            return firstNumber.truncatingRemainder(dividingBy: secondNumber)
        }
    }
}

let calculator = Calculator("90", "9")
let addResult = calculator.add()            // 덧셈 연산
let subtractResult = calculator.sub()       // 뺄셈 연산
let multiplyResult = calculator.mul()       // 곱셈 연산
let divideResult = calculator.div()         // 나눗셈 연산
let remainderResult = calculator.remain()  // 나머지 값.

print("더하기 : \(addResult)")
print("빼기 : \(subtractResult)")
print("곱하기 : \(multiplyResult)")
print("나누기 : \(divideResult)")


